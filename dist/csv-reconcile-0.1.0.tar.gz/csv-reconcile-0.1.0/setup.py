# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['csv_reconcile']

package_data = \
{'': ['*']}

install_requires = \
['flask>=1.1.2,<2.0.0']

entry_points = \
{'console_scripts': ['csv-reconcile = csv_reconcile:main']}

setup_kwargs = {
    'name': 'csv-reconcile',
    'version': '0.1.0',
    'description': 'OpenRefine reconciliation service backed by csv resource',
    'long_description': None,
    'author': 'Douglas Mennella',
    'author_email': 'douglas.mennella@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
